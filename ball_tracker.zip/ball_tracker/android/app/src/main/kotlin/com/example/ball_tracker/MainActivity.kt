package com.example.ball_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
